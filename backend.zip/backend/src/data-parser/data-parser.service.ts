import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { parse } from 'csv-parse/sync';
import { VesselScheduleRecord } from './interfaces/vessel-schedule.interface';

@Injectable()
export class DataParserService {
  private readonly logger = new Logger(DataParserService.name);

  parse(rawCsv: string): { records: VesselScheduleRecord[]; errors: { vesselName?: string; message: string }[] } {
    if (!rawCsv || rawCsv.trim().length === 0) {
      throw new BadRequestException('CSV file is empty');
    }

    let rows: any[];
    try {
      rows = parse(rawCsv, {
        columns: true,
        skip_empty_lines: true,
        trim: true,
        from_line: 2, // Skip the first metadata row in the sample
      });
    } catch (error) {
      this.logger.error('Failed to parse CSV structure', error);
      throw new BadRequestException('Invalid CSV structure');
    }

    if (rows.length === 0) {
      throw new BadRequestException('CSV contains no data rows');
    }

    const records: VesselScheduleRecord[] = [];
    const errors: { vesselName?: string; message: string }[] = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const vesselName = row['Vessel Name'] || `Row ${i + 2}`;
      
      try {
        if (!row['Vessel Name']) {
          throw new BadRequestException(`Missing required value 'Vessel Name' at row ${i + 2}`);
        }
        if (!row['Phase']) {
          throw new BadRequestException(`Missing required value 'Phase' (Status)`);
        }

        const parseDate = (val: string) => {
          if (!val || val.trim() === '') return null;
          const date = new Date(val);
          return isNaN(date.getTime()) ? null : date;
        };

        records.push({
          vesselName: row['Vessel Name'],
          status: row['Phase'],
          loa: parseFloat(row['Vessel Loa M']) || 0,
          foreMeter: parseFloat(row['Bollard Fore Meter']) || 0,
          aftMeter: parseFloat(row['Bollard Aft Meter']) || 0,
          eta: parseDate(row['ETA']),
          ata: parseDate(row['ATA']),
          etd: parseDate(row['ETD']),
        });
      } catch (err: any) {
        errors.push({
          vesselName: vesselName,
          message: err.message,
        });
      }
    }

    return { records, errors };
  }
}
