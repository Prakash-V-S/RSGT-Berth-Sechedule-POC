import { Injectable, Logger } from '@nestjs/common';
import * as ExcelJS from 'exceljs';
import { VesselScheduleRecord } from '../data-parser/interfaces/vessel-schedule.interface';
import { PositionEngineService } from '../position-engine/position-engine.service';
import { ConfigService } from '@nestjs/config';
import * as path from 'path';

interface ProcessedRecord {
  record: VesselScheduleRecord;
  positioned: any; // from PositionEngine
  isValid: boolean;
  error?: string;
}

@Injectable()
export class ExcelGeneratorService {
  private readonly logger = new Logger(ExcelGeneratorService.name);
  
  // Grid configuration
  private readonly METERS_PER_COL = 5;
  private readonly TIME_COL_INDEX = 1;
  private readonly BERTH_START_COL = 2; // Grid starts at column B
  private readonly HEADER_ROWS = 6;
  private readonly GRID_START_ROW = 7; // Grid starts at row 7

  constructor(
    private readonly positionEngine: PositionEngineService,
    private readonly configService: ConfigService,
  ) {}

  async generateBerthPlan(records: VesselScheduleRecord[], outputPath: string) {
    const workbook = new ExcelJS.Workbook();
    
    workbook.creator = 'RSGT Berth Schedule POC';
    workbook.created = new Date();

    const mainSheet = workbook.addWorksheet('MAIN BERTH PLAN', {
      properties: { defaultColWidth: 2, defaultRowHeight: 20 },
      views: [{ state: 'frozen', ySplit: this.GRID_START_ROW - 1, xSplit: this.TIME_COL_INDEX }]
    });

    const summarySheet = workbook.addWorksheet('DATA SUMMARY');

    // Process records through Position Engine
    const processed: ProcessedRecord[] = [];
    let minTime = Infinity;
    let maxTime = -Infinity;

    for (const record of records) {
      try {
        const positioned = this.positionEngine.computePosition(record);
        
        // Basic validation
        const berthLength = this.configService.get<number>('BERTH_LENGTH') || 600;
        if (positioned.position.startMeter < 0) {
          throw new Error(`startMeter (${positioned.position.startMeter}) cannot be less than 0`);
        }
        if (positioned.position.endMeter > berthLength) {
          throw new Error(`endMeter (${positioned.position.endMeter}) exceeds berth length (${berthLength})`);
        }

        processed.push({ record, positioned, isValid: true });

        const sTime = positioned.position.startTime.getTime();
        const eTime = positioned.position.endTime.getTime();
        if (sTime < minTime) minTime = sTime;
        if (eTime > maxTime) maxTime = eTime;

      } catch (err: any) {
        processed.push({ record, positioned: null, isValid: false, error: err.message });
      }
    }

    // Determine Schedule Date Range
    const envStart = this.configService.get<string>('PLAN_START_DATE');
    const envEnd = this.configService.get<string>('PLAN_END_DATE');

    let scheduleStart = envStart ? new Date(envStart).getTime() : minTime;
    let scheduleEnd = envEnd ? new Date(envEnd).getTime() : maxTime;

    if (scheduleStart === Infinity) {
      // Fallback if no valid vessels and no env vars
      scheduleStart = Date.now();
      scheduleEnd = Date.now() + 7 * 24 * 60 * 60 * 1000; // +7 days
    }

    // Snap start to midnight
    const startDate = new Date(scheduleStart);
    startDate.setHours(0, 0, 0, 0);
    scheduleStart = startDate.getTime();

    // Snap end to end of day
    const endDate = new Date(scheduleEnd);
    endDate.setHours(23, 59, 59, 999);
    scheduleEnd = endDate.getTime();

    const totalHours = Math.ceil((scheduleEnd - scheduleStart) / (1000 * 60 * 60));
    const berthLength = this.configService.get<number>('BERTH_LENGTH') || 600;
    const totalCols = Math.ceil(berthLength / this.METERS_PER_COL);

    // --- SETUP MAIN SHEET ---
    
    // Set time column width
    mainSheet.getColumn(this.TIME_COL_INDEX).width = 15;
    
    // Set berth column widths
    for (let i = 0; i < totalCols; i++) {
      mainSheet.getColumn(this.BERTH_START_COL + i).width = 2.5; // Narrow columns for grid
    }

    // Headers
    mainSheet.mergeCells(1, 1, 2, this.BERTH_START_COL + totalCols - 1);
    const titleCell = mainSheet.getCell(1, 1);
    titleCell.value = 'RSGT LOGO / HEADER\nRED SEA GATEWAY TERMINAL';
    titleCell.font = { bold: true, size: 16 };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };

    mainSheet.mergeCells(3, 1, 3, this.BERTH_START_COL + totalCols - 1);
    const subtitleCell = mainSheet.getCell(3, 1);
    subtitleCell.value = 'BERTH / QUAY INFORMATION';
    subtitleCell.font = { bold: true };
    subtitleCell.alignment = { horizontal: 'left', vertical: 'middle' };

    // Draw Berth/Quay Zones (Simplified mapping based on meters)
    // Roughly mapping R1, R2, R3, R4, B5, B6, B7
    const quayZones = [
      { name: 'R1', start: 0, end: 100 },
      { name: 'R2', start: 100, end: 200 },
      { name: 'R3', start: 200, end: 300 },
      { name: 'R4', start: 300, end: 400 },
      { name: 'B5', start: 400, end: 470 },
      { name: 'B6', start: 470, end: 540 },
      { name: 'B7', start: 540, end: 600 },
    ];

    let currentZoneRow = 4;
    for (const zone of quayZones) {
      const startCol = this.BERTH_START_COL + Math.floor(zone.start / this.METERS_PER_COL);
      const endCol = this.BERTH_START_COL + Math.ceil(zone.end / this.METERS_PER_COL) - 1;
      
      if (startCol <= endCol) {
        mainSheet.mergeCells(currentZoneRow, startCol, currentZoneRow, endCol);
        const cell = mainSheet.getCell(currentZoneRow, startCol);
        cell.value = zone.name;
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
        cell.border = {
          top: { style: 'thin' },
          bottom: { style: 'thin' },
          left: { style: 'thin' },
          right: { style: 'thin' }
        };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9EAD3' } }; // Light green
      }
    }

    // Commercial QC row
    mainSheet.mergeCells(5, this.BERTH_START_COL, 5, this.BERTH_START_COL + totalCols - 1);
    const qcCell = mainSheet.getCell(5, this.BERTH_START_COL);
    qcCell.value = 'COMMERCIAL QC / HOURLY QC';
    qcCell.alignment = { horizontal: 'center', vertical: 'middle' };
    qcCell.border = { bottom: { style: 'medium' } };

    // --- DRAW GRID & TIME AXIS ---
    
    let currentRow = this.GRID_START_ROW;
    let currentDayStr = '';

    for (let h = 0; h < totalHours; h++) {
      const currentSlotTime = new Date(scheduleStart + h * 60 * 60 * 1000);
      const dayStr = currentSlotTime.toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'short', year: 'numeric' });
      
      // Print day grouping if changed
      if (dayStr !== currentDayStr) {
        currentDayStr = dayStr;
        const dayCell = mainSheet.getCell(currentRow, this.TIME_COL_INDEX);
        dayCell.value = dayStr.toUpperCase();
        dayCell.font = { bold: true };
        dayCell.alignment = { horizontal: 'center', vertical: 'middle' };
        dayCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEEEEEE' } };
        dayCell.border = { top: { style: 'thin' }, bottom: { style: 'thin' } };
        // Grid separator for day
        for (let i = 0; i < totalCols; i++) {
          mainSheet.getCell(currentRow, this.BERTH_START_COL + i).border = { top: { style: 'medium' } };
        }
      }

      // Operational time slots (e.g. 0801-1000) every 2 hours
      if (h % 2 === 0) {
        const nextSlotTime = new Date(currentSlotTime.getTime() + 2 * 60 * 60 * 1000);
        
        let startHour = currentSlotTime.getHours().toString().padStart(2, '0');
        let startMin = '01';
        if (startHour === '00' && currentSlotTime.getMinutes() === 0) startMin = '01';

        let endHour = nextSlotTime.getHours().toString().padStart(2, '0');
        let endMin = '00';
        if (endHour === '00' && h > 0) {
           endHour = '23';
           endMin = '59';
        }

        const timeLabel = `${startHour}${startMin}-${endHour}${endMin}`;
        
        // Merge 2 rows for the time label
        mainSheet.mergeCells(currentRow, this.TIME_COL_INDEX, currentRow + 1, this.TIME_COL_INDEX);
        const timeCell = mainSheet.getCell(currentRow, this.TIME_COL_INDEX);
        timeCell.value = timeLabel;
        timeCell.alignment = { horizontal: 'center', vertical: 'middle' };
        timeCell.border = { bottom: { style: 'dotted' } };
        
        // Dotted grid lines
        for (let i = 0; i < totalCols; i++) {
          mainSheet.getCell(currentRow + 1, this.BERTH_START_COL + i).border = { bottom: { style: 'dotted' } };
        }
      }

      currentRow++;
    }

    // --- PLOT VESSELS ---
    
    for (const p of processed) {
      if (!p.isValid || !p.positioned) continue;

      const pos = p.positioned.position;
      
      const startMs = pos.startTime.getTime();
      const endMs = pos.endTime.getTime();

      // Skip if completely out of bounds (shouldn't happen if dates are snapped correctly)
      if (endMs < scheduleStart || startMs > scheduleEnd) continue;

      // Calculate row bounds
      const startHourOffset = (startMs - scheduleStart) / (1000 * 60 * 60);
      const endHourOffset = (endMs - scheduleStart) / (1000 * 60 * 60);
      
      const rowStart = this.GRID_START_ROW + Math.floor(startHourOffset);
      const rowEnd = this.GRID_START_ROW + Math.max(Math.ceil(endHourOffset) - 1, Math.floor(startHourOffset)); // Ensure at least 1 row

      // Calculate col bounds
      const colStart = this.BERTH_START_COL + Math.floor(pos.startMeter / this.METERS_PER_COL);
      const colEnd = this.BERTH_START_COL + Math.max(Math.ceil(pos.endMeter / this.METERS_PER_COL) - 1, Math.floor(pos.startMeter / this.METERS_PER_COL));

      try {
        mainSheet.mergeCells(rowStart, colStart, rowEnd, colEnd);
        const vesselCell = mainSheet.getCell(rowStart, colStart);

        const formatDate = (d: Date) => {
          return `${d.getDate().toString().padStart(2, '0')}/${d.getHours().toString().padStart(2, '0')}${d.getMinutes().toString().padStart(2, '0')}`;
        };

        const etaStr = p.record.eta ? formatDate(p.record.eta) : '';
        const ataStr = p.record.ata ? formatDate(p.record.ata) : '';
        const etdStr = p.record.etd ? formatDate(p.record.etd) : '';

        const arrivalStr = p.record.status.toLowerCase() === 'inbound' ? `ETA ${etaStr}` : `ATA ${ataStr}`;

        let text = `${p.record.vesselName}\n`;
        text += `LOA ${p.record.loa}M\n`;
        text += `${arrivalStr}\n`;
        text += `ETD ${etdStr}`;

        if (pos.loaMismatch) {
           text += `\n(LOA Mismatch)`;
        }

        vesselCell.value = text;
        vesselCell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
        
        // Colors
        const isWorking = p.record.status.toLowerCase() === 'working';
        const bgColor = isWorking ? 'FF90CAF9' : 'FFA5D6A7'; // Blue for working, Green for inbound

        vesselCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgColor } };
        vesselCell.border = {
          top: { style: 'thick' },
          bottom: { style: 'thick' },
          left: { style: 'thick' },
          right: { style: 'thick' }
        };
      } catch (mergeErr: any) {
        // Can happen if cells overlap (ExcelJS throws error on overlapping merges)
        this.logger.warn(`Could not plot vessel ${p.record.vesselName} due to overlap or bounds: ${mergeErr.message}`);
      }
    }

    // --- SETUP SUMMARY SHEET ---
    summarySheet.columns = [
      { header: 'Vessel Name', key: 'vesselName', width: 25 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Validation', key: 'validation', width: 15 },
      { header: 'Error Message', key: 'error', width: 40 },
      { header: 'LOA', key: 'loa', width: 10 },
      { header: 'Fore Meter', key: 'foreMeter', width: 15 },
      { header: 'Aft Meter', key: 'aftMeter', width: 15 },
    ];

    summarySheet.getRow(1).font = { bold: true };

    for (const p of processed) {
      summarySheet.addRow({
        vesselName: p.record.vesselName,
        status: p.record.status,
        validation: p.isValid ? 'VALID' : 'INVALID',
        error: p.error || '',
        loa: p.record.loa,
        foreMeter: p.record.foreMeter,
        aftMeter: p.record.aftMeter,
      });
    }

    // Write file
    const outputDir = path.dirname(outputPath);
    const fs = require('fs');
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    await workbook.xlsx.writeFile(outputPath);
    
    // Return summary for CLI
    return {
      total: processed.length,
      successful: processed.filter(p => p.isValid).length,
      invalid: processed.filter(p => !p.isValid).length,
      errors: processed.filter(p => !p.isValid).map(p => ({ vesselName: p.record.vesselName, message: p.error }))
    };
  }
}
